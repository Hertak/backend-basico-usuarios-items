## Bakend básico para creación de usuarios con JWT y Mongo db

- Creación de usuario 
- Login de usuario
- Renovación de Token de JWT
- Agregado de item, editado, borrado y listado


Hecho en Node es quizás lo más básico que se puede encontrar